<?php

$nursestart = "SELECT name FROM ward";

