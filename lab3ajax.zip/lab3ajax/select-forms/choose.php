<?php

$choosestart = "SELECT name FROM nurse";