<?php

$shiftsstart = "SELECT DISTINCT shift FROM nurse";